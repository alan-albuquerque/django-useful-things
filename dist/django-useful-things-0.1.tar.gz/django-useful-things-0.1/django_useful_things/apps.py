from django.apps import AppConfig


class DjangoUsefulThingsConfig(AppConfig):
    name = 'django_useful_things'
