=====
Django Useful Things
=====

Models:
-----------
- SoftDeleteModel
- AddressModel
- WeekDayModelMixin
